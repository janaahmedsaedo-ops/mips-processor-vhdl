----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 23:17:04 11/25/2025 
-- Design Name: registerfile
-- Module Name: registerfile - Behavioral 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
-- Include the package to make components visible
use work.datapathpack.all; 

entity registerfile is
    generic(n: natural := 32); 
    Port ( 
        write_sel    : in  STD_LOGIC_VECTOR (4 downto 0);    -- Write register address
        write_ena    : in  STD_LOGIC;                         -- Write enable control
        write_data   : in  STD_LOGIC_VECTOR (n-1 downto 0);    -- Data to write
        read_sel1    : in  STD_LOGIC_VECTOR (4 downto 0);    -- Read address 1
        read_sel2    : in  STD_LOGIC_VECTOR (4 downto 0);    -- Read address 2
        data1        : out STD_LOGIC_VECTOR (n-1 downto 0);    -- Data output 1
        data2        : out STD_LOGIC_VECTOR (n-1 downto 0);    -- Data output 2
        clk          : in  STD_LOGIC
    );
end registerfile;

architecture Behavioral of registerfile is

    -- internal reset signal (active-high synchronous reset)
    signal reset : std_logic := '0';

    -- decoder output
    signal dec_out : std_logic_vector(31 downto 0);

    -- per-register load signals
    signal load0  : std_logic;  signal load1  : std_logic;
    signal load2  : std_logic;  signal load3  : std_logic;
    signal load4  : std_logic;  signal load5  : std_logic;
    signal load6  : std_logic;  signal load7  : std_logic;
    signal load8  : std_logic;  signal load9  : std_logic;
    signal load10 : std_logic;  signal load11 : std_logic;
    signal load12 : std_logic;  signal load13 : std_logic;
    signal load14 : std_logic;  signal load15 : std_logic;
    signal load16 : std_logic;  signal load17 : std_logic;
    signal load18 : std_logic;  signal load19 : std_logic;
    signal load20 : std_logic;  signal load21 : std_logic;
    signal load22 : std_logic;  signal load23 : std_logic;
    signal load24 : std_logic;  signal load25 : std_logic;
    signal load26 : std_logic;  signal load27 : std_logic;
    signal load28 : std_logic;  signal load29 : std_logic;
    signal load30 : std_logic;  signal load31 : std_logic;

    -- register outputs (using n instead of hardcoded 32)
    signal q0,  q1,  q2,  q3,  q4,  q5,  q6,  q7 : std_logic_vector(n-1 downto 0);
    signal q8,  q9,  q10, q11, q12, q13, q14, q15 : std_logic_vector(n-1 downto 0);
    signal q16, q17, q18, q19, q20, q21, q22, q23 : std_logic_vector(n-1 downto 0);
    signal q24, q25, q26, q27, q28, q29, q30, q31 : std_logic_vector(n-1 downto 0);

begin

    -- Instantiate Decoder5to32 (Used: write_sel)
    dec_inst : decoder port map (
        write_sel, dec_out
    );

    -- Generate per-register loads (Used: write_ena)
    load0  <= write_ena and dec_out(0);     load1  <= write_ena and dec_out(1);
    load2  <= write_ena and dec_out(2);     load3  <= write_ena and dec_out(3);
    load4  <= write_ena and dec_out(4);     load5  <= write_ena and dec_out(5);
    load6  <= write_ena and dec_out(6);     load7  <= write_ena and dec_out(7);
    load8  <= write_ena and dec_out(8);     load9  <= write_ena and dec_out(9);
    load10 <= write_ena and dec_out(10);    load11 <= write_ena and dec_out(11);
    load12 <= write_ena and dec_out(12);    load13 <= write_ena and dec_out(13);
    load14 <= write_ena and dec_out(14);    load15 <= write_ena and dec_out(15);
    load16 <= write_ena and dec_out(16);    load17 <= write_ena and dec_out(17);
    load18 <= write_ena and dec_out(18);    load19 <= write_ena and dec_out(19);
    load20 <= write_ena and dec_out(20);    load21 <= write_ena and dec_out(21);
    load22 <= write_ena and dec_out(22);    load23 <= write_ena and dec_out(23);
    load24 <= write_ena and dec_out(24);    load25 <= write_ena and dec_out(25);
    load26 <= write_ena and dec_out(26);    load27 <= write_ena and dec_out(27);
    load28 <= write_ena and dec_out(28);    load29 <= write_ena and dec_out(29);
    load30 <= write_ena and dec_out(30);    load31 <= write_ena and dec_out(31);

    -- Instantiate 32 Flopr registers (Used: write_data)
    rf0 : flopr generic map (n) port map (clk, load0, reset, write_data, q0);
    rf1 : flopr generic map (n) port map (clk, load1, reset, write_data, q1);
    rf2 : flopr generic map (n) port map (clk, load2, reset, write_data, q2);
    rf3 : flopr generic map (n) port map (clk, load3, reset, write_data, q3);
    rf4 : flopr generic map (n) port map (clk, load4, reset, write_data, q4);
    rf5 : flopr generic map (n) port map (clk, load5, reset, write_data, q5);
    rf6 : flopr generic map (n) port map (clk, load6, reset, write_data, q6);
    rf7 : flopr generic map (n) port map (clk, load7, reset, write_data, q7);
    rf8 : flopr generic map (n) port map (clk, load8, reset, write_data, q8);
    rf9 : flopr generic map (n) port map (clk, load9, reset, write_data, q9);
    rf10: flopr generic map (n) port map (clk, load10, reset, write_data, q10);
    rf11: flopr generic map (n) port map (clk, load11, reset, write_data, q11);
    rf12: flopr generic map (n) port map (clk, load12, reset, write_data, q12);
    rf13: flopr generic map (n) port map (clk, load13, reset, write_data, q13);
    rf14: flopr generic map (n) port map (clk, load14, reset, write_data, q14);
    rf15: flopr generic map (n) port map (clk, load15, reset, write_data, q15);
    rf16: flopr generic map (n) port map (clk, load16, reset, write_data, q16);
    rf17: flopr generic map (n) port map (clk, load17, reset, write_data, q17);
    rf18: flopr generic map (n) port map (clk, load18, reset, write_data, q18);
    rf19: flopr generic map (n) port map (clk, load19, reset, write_data, q19);
    rf20: flopr generic map (n) port map (clk, load20, reset, write_data, q20);
    rf21: flopr generic map (n) port map (clk, load21, reset, write_data, q21);
    rf22: flopr generic map (n) port map (clk, load22, reset, write_data, q22);
    rf23: flopr generic map (n) port map (clk, load23, reset, write_data, q23);
    rf24: flopr generic map (n) port map (clk, load24, reset, write_data, q24);
    rf25: flopr generic map (n) port map (clk, load25, reset, write_data, q25);
    rf26: flopr generic map (n) port map (clk, load26, reset, write_data, q26);
    rf27: flopr generic map (n) port map (clk, load27, reset, write_data, q27);
    rf28: flopr generic map (n) port map (clk, load28, reset, write_data, q28);
    rf29: flopr generic map (n) port map (clk, load29, reset, write_data, q29);
    rf30: flopr generic map (n) port map (clk, load30, reset, write_data, q30);
    rf31: flopr generic map (n) port map (clk, load31, reset, write_data, q31);

    -- Instantiate two 32-to-1 muxes for reading (Used: read_sel1, data1, read_sel2, data2)
    mux1: mux generic map (n) port map (
        read_sel1, data1, 
        q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11,
        q12, q13, q14, q15, q16, q17, q18, q19, q20, q21,
        q22, q23, q24, q25, q26, q27, q28, q29, q30, q31
    );

    mux2: mux generic map (n) port map (
        read_sel2, data2,
        q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11,
        q12, q13, q14, q15, q16, q17, q18, q19, q20, q21,
        q22, q23, q24, q25, q26, q27, q28, q29, q30, q31
    );

end Behavioral;