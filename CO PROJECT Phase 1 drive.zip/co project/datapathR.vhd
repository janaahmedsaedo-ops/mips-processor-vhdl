----------------------------------------------------------------------------------
-- Entity: datapath
-- Description: Simple MIPS Datapath for R-type instructions (AND, OR, ADD, SUB, SLT, NOR).
-- Connects Register File and ALU using positional mapping.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
-- Assumes datapathpack includes: registerfile, alumodule1
use work.datapathpack.all; 

entity datapath is
    generic(n: natural := 32); -- Data width
    Port ( 
        -- Control & Clock Ports
        clk           : in  STD_LOGIC;
        reset         : in  STD_LOGIC;      -- Used to reset registers
        regwrite      : in  STD_LOGIC;      -- Write enable control for the Register File

        -- Instruction & ALU Ports
        instr         : in  STD_LOGIC_VECTOR (31 downto 0); -- Full instruction
        aluoperation  : in  STD_LOGIC_VECTOR (3 downto 0);  -- ALU Function Select

        -- Status & Output Ports
        zero          : out STD_LOGIC;                      -- Zero Flag from ALU
        aluout        : buffer STD_LOGIC_VECTOR (n-1 downto 0) -- ALU Result (Feeds back to Reg File)
    );
end datapath;

architecture Behavioral of datapath is

    -- Register File Read Data Signals (Outputs of RegFile, Inputs to ALU)
    signal read_data_1 : STD_LOGIC_VECTOR(n-1 downto 0);
    signal read_data_2 : STD_LOGIC_VECTOR(n-1 downto 0);
    
    -- Register Field Signals (Addresses derived from instruction)
    -- Addresses are 5 bits wide (2^5 = 32 registers)
    signal read_reg_1  : STD_LOGIC_VECTOR(4 downto 0);   -- R-type: rs (25:21)
    signal read_reg_2  : STD_LOGIC_VECTOR(4 downto 0);   -- R-type: rt (20:16)
    signal write_reg   : STD_LOGIC_VECTOR(4 downto 0);   -- R-type: rd (15:11)
    
begin
    
    -- ----------------------------------------------------
    -- 1. Instruction Fields Decoding (Wire Connections)
    -- ----------------------------------------------------
    read_reg_1 <= instr(25 downto 21);
    read_reg_2 <= instr(20 downto 16);
    write_reg <= instr(15 downto 11);
    
    -- ----------------------------------------------------
    -- 2. Register File Instantiation
    -- Positional Mapping Order (from datapathpack): 
    -- (write_sel, write_ena, write_data, read_sel1, read_sel2, data1, data2, clk)
    -- ----------------------------------------------------
    reg_file_inst : registerfile 
        generic map (n) 
        port map (
            write_reg,      -- 1. write_sel
            regwrite,       -- 2. write_ena
            aluout,         -- 3. write_data
            read_reg_1,     -- 4. read_sel1
            read_reg_2,     -- 5. read_sel2
            read_data_1,    -- 6. data1
            read_data_2,    -- 7. data2
            clk             -- 8. clk
        );

    -- ----------------------------------------------------
    -- 3. ALU Instantiation
    -- Positional Mapping Order (from datapathpack): 
    -- (data1, data2, aluop, dataout, zflag)
    -- ----------------------------------------------------
    alu_inst : aluprj 
        port map (
            read_data_1,    -- 1. data1
            read_data_2,    -- 2. data2
            aluoperation,   -- 3. aluop
            aluout,         -- 4. dataout
            zero            -- 5. zflag
        );

end Behavioral;