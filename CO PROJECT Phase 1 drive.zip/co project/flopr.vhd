-- Standard IEEE libraries are required for STD_LOGIC_VECTOR and rising_edge
library IEEE;
use IEEE.STD_LOGIC_1164.all;


-- The entity definition
entity flopr is
    generic(n: natural := 32); -- Parameter for data width
    Port (
        clk   : in  STD_LOGIC;
        load  : in  STD_LOGIC; -- Present, but currently unused in the architecture
        reset : in  STD_LOGIC;
        D     : in  STD_LOGIC_VECTOR (n-1 downto 0);
        Q     : out STD_LOGIC_VECTOR (n-1 downto 0)
    );
end flopr;

-- The behavioral architecture
architecture Behavioral of flopr is
begin

    -- Sequential logic process, sensitive to clock and asynchronous reset
    process(clk, reset)
    begin
      if reset = '1' then
        Q <= (others => '0');
    elsif rising_edge(clk) then
        -- Load data D into Q ONLY if load is high
        if load = '1' then
            Q <= D;
        end if;
    end if;
    end process;

end Behavioral;