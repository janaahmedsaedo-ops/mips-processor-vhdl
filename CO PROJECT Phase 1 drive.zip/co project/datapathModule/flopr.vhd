library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity flopr is
    generic ( n : natural := 32 );
    port (
        clk   : in  STD_LOGIC;
        load  : in  STD_LOGIC;
        reset : in  STD_LOGIC;
        D     : in  STD_LOGIC_VECTOR (n-1 downto 0);
        Q     : out STD_LOGIC_VECTOR (n-1 downto 0)
    );
end flopr;

architecture Behavioral of flopr is
begin
    process(clk, reset)
    begin
        if reset = '1' then
            Q <= (others => '0');
        elsif rising_edge(clk) then
            if load = '1' then
                Q <= D;
            end if;
        end if;
    end process;
end Behavioral;

