--
--	Package File Template
--
--	Purpose: This package defines supplemental types, subtypes, 
--		 constants, and functions 
--
--   To use any of the example code shown below, uncomment the lines and modify as necessary
--

library IEEE;
use IEEE.STD_LOGIC_1164.all;

package datapathhpack is
--flopr component
component flopr is
generic(n:natural:=32);
    Port ( clk : in  STD_LOGIC;
           load : in  STD_LOGIC;
           reset : in  STD_LOGIC;
           D : in  STD_LOGIC_VECTOR (n-1 downto 0);
           Q : out  STD_LOGIC_VECTOR (n-1 downto 0));
end component;
--mux2 component
component mux2 is
 generic ( n : natural := 32 );
    Port ( I0 : in  STD_LOGIC_VECTOR (n-1 downto 0);
           I1 : in  STD_LOGIC_VECTOR (n-1 downto 0);
           S : in  STD_LOGIC;
           y : out  STD_LOGIC_VECTOR (n-1 downto 0));
end component;
--sl2 component
component sl2 is
    Port ( a : in  STD_LOGIC_VECTOR (31 downto 0);
           y : out  STD_LOGIC_VECTOR (31 downto 0));
end component;

--adder component
component adder is
    Port ( a : in  STD_LOGIC_VECTOR (31 downto 0);
           b : in  STD_LOGIC_VECTOR (31 downto 0);
           s : out  STD_LOGIC_VECTOR (31 downto 0);
           cin : in  STD_LOGIC;
           cout : out  STD_LOGIC);
end component;
-- sigenext component
 component signext is
    Port ( a : in  STD_LOGIC_VECTOR (15 downto 0);
           y : out  STD_LOGIC_VECTOR (31 downto 0));
end  component;
-- alucomponent
component alumodule1 is
    Port ( data1 : in  STD_LOGIC_VECTOR (31 downto 0);
           data2 : in  STD_LOGIC_VECTOR (31 downto 0);
           aluop : in  STD_LOGIC_VECTOR (3 downto 0);
           dataout : out  STD_LOGIC_VECTOR (31 downto 0);
           zflag : out  STD_LOGIC);
end component;
--mux component

component mux is
    generic(n:natural:=32);  -- The width of each input and output (32 bits)
    Port (
        sel    : in  STD_LOGIC_VECTOR (4 downto 0);    -- 5-bit select input (RENAMED from 'select')
        muxout : out STD_LOGIC_VECTOR (n-1 downto 0);  -- 32-bit output
        Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11,
        Q12, Q13, Q14, Q15, Q16, Q17, Q18, Q19, Q20, Q21,
        Q22, Q23, Q24, Q25, Q26, Q27, Q28, Q29, Q30, Q31 : in STD_LOGIC_VECTOR (n-1 downto 0)  -- 32-bit inputs
    );
end component;
--decoder component
component decoder is
generic(n: natural := 32);
  port (
    sel : in  std_logic_vector(4 downto 0);
    output : out std_logic_vector(n-1 downto 0)
  );
end component;
--registerfile component
component registerfile is
    generic(n: natural := 32); 
    Port ( 
        write_sel    : in  STD_LOGIC_VECTOR (4 downto 0);    -- Write register address
        write_ena    : in  STD_LOGIC;                         -- Write enable control
        write_data   : in  STD_LOGIC_VECTOR (n-1 downto 0);    -- Data to write
        read_sel1    : in  STD_LOGIC_VECTOR (4 downto 0);    -- Read address 1
        read_sel2    : in  STD_LOGIC_VECTOR (4 downto 0);    -- Read address 2
        data1        : out STD_LOGIC_VECTOR (n-1 downto 0);    -- Data output 1
        data2        : out STD_LOGIC_VECTOR (n-1 downto 0);    -- Data output 2
        clk          : in  STD_LOGIC;
		  reset        : in STD_LOGIC
    );
end component;




end datapathhpack;

