----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    14:46:27 12/13/2025 
-- Design Name: 
-- Module Name:    datapath - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.datapathhpack.all; 


entity datapath is
    generic ( n : natural := 32 );
    Port ( clk : in  STD_LOGIC;
           reset : in  STD_LOGIC;
           readdata : in  STD_LOGIC_VECTOR (31 downto 0);
           instr : in  STD_LOGIC_VECTOR (31 downto 0);
           memtoreg : in  STD_LOGIC;
           pcsrc : in  STD_LOGIC;
           alusrc : in  STD_LOGIC;
           regwrite : in  STD_LOGIC;
           regdst : in  STD_LOGIC;
			  jump : in STD_LOGIC;
           aluoperation : in  STD_LOGIC_VECTOR (3 downto 0);
           zero : out  STD_LOGIC;
           pc_main : out  STD_LOGIC_VECTOR (31 downto 0);
           aluout_main : out  STD_LOGIC_VECTOR (31 downto 0);
           writedata_main : out  STD_LOGIC_VECTOR (31 downto 0));
end datapath;

architecture Behavioral of datapath is
--buffer replace
signal pc       : STD_LOGIC_VECTOR(31 downto 0);
signal aluout    : STD_LOGIC_VECTOR(31 downto 0);
signal writedata : STD_LOGIC_VECTOR(31 downto 0);

signal writereg: std_logic_vector(4 downto 0); 
signal pcjump, pcnext, pcnextbr, pcplus4, pcbranch: std_logic_vector(31 downto 0);
signal signimm, signimmsh: std_logic_vector(31 downto 0);
signal srca, srcb, result: std_logic_vector(31 downto 0);
signal cout:std_logic;
signal cout2:std_logic;
-- Register File Read Data Signals (Outputs of RegFile, Inputs to ALU)
    signal read_data_1 : STD_LOGIC_VECTOR(n-1 downto 0);
    signal read_data_2 : STD_LOGIC_VECTOR(n-1 downto 0);
    
    -- Register Field Signals (Addresses derived from instruction)
    -- Addresses are 5 bits wide (2^5 = 32 registers)
    signal read_reg_1  : STD_LOGIC_VECTOR(4 downto 0);   -- R-type: rs (25:21)
    signal read_reg_2  : STD_LOGIC_VECTOR(4 downto 0);   -- R-type: rt (20:16)
    signal write_reg   : STD_LOGIC_VECTOR(4 downto 0);
	 signal final_write_reg   : STD_LOGIC_VECTOR(4 downto 0);

signal alu_lower_operand: STD_LOGIC_VECTOR(n-1 downto 0);

begin
--alu lower operand logic
lower_operand:mux2 generic map(32) port map(read_data_2,signimm,alusrc,alu_lower_operand);
--memtoreg logic
write_data_ins:mux2 generic map(32) port map(aluout,readdata,memtoreg,writedata);
--sign extend logic
signextended:signext port map(instr(15 downto 0),signimm);
--alusrc logic

--next PC logic
pcadd1: adder port map(pc, x"00000004", pcplus4,'0',cout); 
pcjump <= pcplus4(31 downto 28) & instr(25 downto 0) & "00";  
pcreg: flopr generic map(32) port map(clk,'1', reset, pcnext, pc);
immsh: sl2 port map(signimm, signimmsh); 
pcadd2: adder port map(pcplus4, signimmsh, pcbranch,'0',cout2); 
pcbrmux: mux2 generic map(32) port map(pcplus4, pcbranch, pcsrc, pcnextbr);
pcmux: mux2 generic map(32) port map(pcnextbr, pcjump, jump, pcnext);
--RegisterFile logic
read_reg_1 <= instr(25 downto 21);
read_reg_2 <= instr(20 downto 16);
write_reg <= instr(15 downto 11);
writereg_ins: mux2 generic map(5) port map(read_reg_2,write_reg, regdst,final_write_reg);
reg_file_inst : registerfile 
        generic map (n) 
        port map (
            final_write_reg,      -- 1. write_register-----------
            regwrite,       -- 2. write_ena
            writedata,         -- 3. write_data
            read_reg_1,     -- 4. read_sel1
            read_reg_2,     -- 5. read_sel2
            read_data_1,    -- 6. data1
            read_data_2,    -- 7. data2
            clk,            -- 8. clk
				reset
        );
--alu logic
alu_inst : alumodule1 
        port map (
            read_data_1,    -- 1. data1
            alu_lower_operand,    -- 2. data2
            aluoperation,   -- 3. aluop
            aluout,         -- 4. dataout
            zero            -- 5. zflag
        );


pc_main       <= pc;
aluout_main    <= aluout;
writedata_main <= writedata;



end Behavioral;

