library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;



entity aluproj is
generic(n: natural := 32); 
    Port ( data1 : in  STD_LOGIC_VECTOR (n-1 downto 0);
           data2 : in  STD_LOGIC_VECTOR (n-1 downto 0);
           aluop : in  STD_LOGIC_VECTOR (3 downto 0);
           dataout : out  STD_LOGIC_VECTOR (n-1 downto 0);
           zflag : out  STD_LOGIC);
end aluproj;


architecture Behavioral of aluproj is
    signal add_res, sub_res : signed(31 downto 0);
signal temp: STD_LOGIC_VECTOR(31 downto 0);
    signal overflow : std_logic;
begin

 
    -- Signed ADD / SUB results
   
    add_res <= signed(data1) + signed(data2);
    sub_res <= signed(data1) - signed(data2);
overflow <= (data1(31) xor data2(31)) and(data1(31) xor std_logic(sub_res(31)));
 process(data1, data2, aluop, add_res, sub_res, overflow)
    begin
        case aluop is

            when "0000" =>  -- AND
                temp <= data1 and data2;

            when "0001" =>  -- OR
                temp <= data1 or data2;

            when "0010" =>  -- ADD (signed)
                temp <= std_logic_vector(add_res);
 when "0110" =>  -- SUB (signed)
                temp <= std_logic_vector(sub_res);

            when "1100" =>  -- NOR
                temp <= not (data1 or data2);

            -- SLT (signed)
                -- SLT = 1 if A < B
                -- = MSB(sub) XOR overflow
            when "0111" =>
temp(31 downto 1) <= (others => '0');
               temp(0) <= sub_res(31) xor overflow;


 when others =>
                temp <= (others => '0');
        end case;

    end process;
 -- Assign internal result to output port
    dataout <= temp;
zflag<='1' when temp=x"00000000"
else '0';

end Behavioral;