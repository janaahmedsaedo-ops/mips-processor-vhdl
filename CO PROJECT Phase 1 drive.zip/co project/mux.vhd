-- Company:
-- Engineer:
--
-- Create Date:   19:29:10 11/24/2025
-- Design Name: 32x32-bit MUX
-- Module Name:   mux - Behavioral
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Corrected entity with 'sel' instead of 'select'
entity mux is
    generic(n:natural:=32);  -- The width of each input and output (32 bits)
    Port (
        sel    : in  STD_LOGIC_VECTOR (4 downto 0);    -- 5-bit select input (RENAMED from 'select')
        muxout : out STD_LOGIC_VECTOR (n-1 downto 0);  -- 32-bit output
        Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11,
        Q12, Q13, Q14, Q15, Q16, Q17, Q18, Q19, Q20, Q21,
        Q22, Q23, Q24, Q25, Q26, Q27, Q28, Q29, Q30, Q31 : 
		  in STD_LOGIC_VECTOR (n-1 downto 0)  -- 32-bit inputs
    );
end mux;

-- Corrected architecture
architecture Behavioral of mux is
begin
    -- Update sensitivity list to use the new name 'sel'
    process(sel, Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11,
            Q12, Q13, Q14, Q15, Q16, Q17, Q18, Q19, Q20, Q21,
            Q22, Q23, Q24, Q25, Q26, Q27, Q28, Q29, Q30, Q31)
    begin
        -- Update 'case' statement to use the new name 'sel'
        case sel is
            when "00000" => muxout <= Q0;
            when "00001" => muxout <= Q1;
            when "00010" => muxout <= Q2;
            when "00011" => muxout <= Q3;
            when "00100" => muxout <= Q4;
            when "00101" => muxout <= Q5;
            when "00110" => muxout <= Q6;
            when "00111" => muxout <= Q7;
            when "01000" => muxout <= Q8;
            when "01001" => muxout <= Q9;
            when "01010" => muxout <= Q10;
            when "01011" => muxout <= Q11;
            when "01100" => muxout <= Q12;
            when "01101" => muxout <= Q13;
            when "01110" => muxout <= Q14;
            when "01111" => muxout <= Q15;
            when "10000" => muxout <= Q16;
            when "10001" => muxout <= Q17;
            when "10010" => muxout <= Q18;
            when "10011" => muxout <= Q19;
            when "10100" => muxout <= Q20;
            when "10101" => muxout <= Q21;
            when "10110" => muxout <= Q22;
            when "10111" => muxout <= Q23;
            when "11000" => muxout <= Q24;
            when "11001" => muxout <= Q25;
            when "11010" => muxout <= Q26;
            when "11011" => muxout <= Q27;
            when "11100" => muxout <= Q28;
            when "11101" => muxout <= Q29;
            when "11110" => muxout <= Q30;
            when "11111" => muxout <= Q31;
            when others => muxout <= (others => '0');
        end case;
    end process;
end Behavioral;