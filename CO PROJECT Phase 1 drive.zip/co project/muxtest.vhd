library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL; -- For TO_INTEGER conversion

-- The entity of the testbench is generally empty
entity mux_tb is
end mux_tb;

architecture Testbench of mux_tb is

    -- Component Declaration for the Unit Under Test (UUT)
    component mux
        generic(n:natural:=32);
        Port (
            sel    : in  STD_LOGIC_VECTOR (4 downto 0);
            muxout : out STD_LOGIC_VECTOR (n-1 downto 0);
            Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11,
            Q12, Q13, Q14, Q15, Q16, Q17, Q18, Q19, Q20, Q21,
            Q22, Q23, Q24, Q25, Q26, Q27, Q28, Q29, Q30, Q31 :
            in STD_LOGIC_VECTOR (n-1 downto 0)
        );
    end component;

    -- Constants
    constant n_bits : natural := 32;
    constant clk_period : time := 10 ns;

    -- Signals for the MUX ports
    signal sel_tb    : STD_LOGIC_VECTOR (4 downto 0) := (others => '0');
    signal muxout_tb : STD_LOGIC_VECTOR (n_bits-1 downto 0);

    -- Signals for the 32 data inputs (using an array type for easier access in a loop)
    type data_array is array (0 to 31) of STD_LOGIC_VECTOR(n_bits-1 downto 0);
    signal Q_data : data_array := (others => (others => '0'));
    
    -- Clock signal (optional for combinational logic, but good practice)
    signal clk_tb : STD_LOGIC := '0';
    signal test_done : boolean := false;

begin

    -- Instantiate the Unit Under Test (UUT)
    uut: mux
        generic map (n => n_bits)
        Port map (
            sel    => sel_tb,
            muxout => muxout_tb,
            Q0  => Q_data(0),  Q1  => Q_data(1),  Q2  => Q_data(2),  Q3  => Q_data(3),
            Q4  => Q_data(4),  Q5  => Q_data(5),  Q6  => Q_data(6),  Q7  => Q_data(7),
            Q8  => Q_data(8),  Q9  => Q_data(9),  Q10 => Q_data(10), Q11 => Q_data(11),
            Q12 => Q_data(12), Q13 => Q_data(13), Q14 => Q_data(14), Q15 => Q_data(15),
            Q16 => Q_data(16), Q17 => Q_data(17), Q18 => Q_data(18), Q19 => Q_data(19),
            Q20 => Q_data(20), Q21 => Q_data(21), Q22 => Q_data(22), Q23 => Q_data(23),
            Q24 => Q_data(24), Q25 => Q_data(25), Q26 => Q_data(26), Q27 => Q_data(27),
            Q28 => Q_data(28), Q29 => Q_data(29), Q30 => Q_data(30), Q31 => Q_data(31)
        );

    -- Clock process (optional)
    clk_process : process
    begin
        while not test_done loop
            clk_tb <= '0';
            wait for clk_period / 2;
            clk_tb <= '1';
            wait for clk_period / 2;
        end loop;
        wait;
    end process;

    -- Stimulus process
    stim_process : process
        -- Helper function to convert an integer index to the 5-bit select vector
        function to_select_vector(index : integer) return STD_LOGIC_VECTOR is
            variable sel_v : STD_LOGIC_VECTOR(4 downto 0);
        begin
            sel_v := STD_LOGIC_VECTOR(TO_UNSIGNED(index, 5));
            return sel_v;
        end function;
        
        -- Helper function to generate a unique data pattern for testing
        function generate_data_pattern(index : integer) return STD_LOGIC_VECTOR is
            variable pattern : STD_LOGIC_VECTOR(n_bits-1 downto 0);
            -- Example pattern: Index repeated in the LSB, remaining bits alternating 1010...
        begin
            pattern := (others => '1'); -- Start with all '1's
            pattern(4 downto 0) := STD_LOGIC_VECTOR(TO_UNSIGNED(index, 5)); -- Index in LSB
            pattern(5) := '0';
            pattern(6) := '1';
            pattern(7) := '0';
            pattern(8) := '1';
            -- For simplicity and readability, let's keep it simple: index in LSB and rest as '1's
            -- This ensures each Q input has a distinct value that also depends on its index.
            pattern(n_bits-1 downto 5) := (others => '1');
            return pattern;
        end function;

    begin
        report "Starting 32x32-bit MUX Testbench";

        -- 1. Initialize all Q inputs with unique data patterns
        for i in 0 to 31 loop
            Q_data(i) <= generate_data_pattern(i);
        end loop;

        wait for clk_period * 2; -- Allow initial propagation delay

        -- 2. Test specific cases
        report "--- Testing specific cases (Q0, Q5, Q16, Q31) ---";

        -- Test Q0 (sel="00000")
        sel_tb <= to_select_vector(0);
        wait for clk_period;
        assert muxout_tb = Q_data(0)
            report "Test Q0 FAILED! Expected: " & std_logic'image(Q_data(0)) & " Got: " & std_logic'image(muxout_tb)