library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
entity decoder is
generic(n: natural := 32);
  port (
    sel : in  std_logic_vector(4 downto 0);
    output : out std_logic_vector(n-1 downto 0)
  );
end entity decoder;

architecture Behavioral of decoder is
begin
  process(sel)
    variable tmp : std_logic_vector(31 downto 0);
  begin
    tmp := (others => '0');
    case sel is
      when "00000" => tmp(0)  := '1';
      when "00001" => tmp(1)  := '1';
      when "00010" => tmp(2)  := '1';
      when "00011" => tmp(3)  := '1';
      when "00100" => tmp(4)  := '1';
      when "00101" => tmp(5)  := '1';
      when "00110" => tmp(6)  := '1';
      when "00111" => tmp(7)  := '1';
      when "01000" => tmp(8)  := '1';
      when "01001" => tmp(9)  := '1';
      when "01010" => tmp(10) := '1';
      when "01011" => tmp(11) := '1';
      when "01100" => tmp(12) := '1';
      when "01101" => tmp(13) := '1';
      when "01110" => tmp(14) := '1';
      when "01111" => tmp(15) := '1';
      when "10000" => tmp(16) := '1';
      when "10001" => tmp(17) := '1';
      when "10010" => tmp(18) := '1';
      when "10011" => tmp(19) := '1';
      when "10100" => tmp(20) := '1';
      when "10101" => tmp(21) := '1';
      when "10110" => tmp(22) := '1';
      when "10111" => tmp(23) := '1';
      when "11000" => tmp(24) := '1';
      when "11001" => tmp(25) := '1';
      when "11010" => tmp(26) := '1';
      when "11011" => tmp(27) := '1';
      when "11100" => tmp(28) := '1';
      when "11101" => tmp(29) := '1';
      when "11110" => tmp(30) := '1';
      when "11111" => tmp(31) := '1';
      when others  => tmp := (others => '0');
    end case;
    output <= tmp;
  end process;
end architecture Behavioral;